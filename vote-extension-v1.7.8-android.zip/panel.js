// Isolated content script on vote.mtv.com. Draws the BLINKS UNITED vote panel
// directly on the page (in a shadow root so MTV's CSS can't touch it), fed by the
// counters/log that background.js keeps in chrome.storage. Shows the live "blinks
// voting now" pulse. Never touches the MTV voting UI — it only reads our own state.
(function () {
  if (window.__buPanelMounted) return;         // guard against double-inject
  window.__buPanelMounted = true;
  if (window.top !== window) return;            // top frame only

  // One panel, two awards. On vote.mtv.com it's the VMA counter; on
  // vote.breaktudoawards.com it's the BreakTudo counter. They keep entirely
  // separate storage keys and read their own award dimension off the board.
  const AWARD = /(^|\.)vote\.breaktudoawards\.com$/i.test(location.hostname) ? 'breaktudo' : 'vma';
  const CFG = AWARD === 'breaktudo'
    ? { sub: 'BreakTudo Vote Counter', unit: 'votes · synced to /voting',
        countKey: 'btCount', logKey: 'btLog' }
    : { sub: 'VMA Vote Counter', unit: 'votes · synced to /voting',
        countKey: 'buCount', logKey: 'buLog' };

  // Extension-context guard: if the extension is reloaded/uninstalled while this
  // tab is open, every chrome.runtime/storage call throws "Extension context
  // invalidated." Check first and bail out of any dead context silently.
  function validCtx() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (_) { return false; }
  }
  function safeCtx(fn) {
    if (!validCtx()) return undefined;
    try { return fn(); } catch (_) { return undefined; }
  }
  if (!validCtx()) return;

  // ── "which nominee is this candidate id?" ─────────────────────────────────
  // Int. Music Video has two of ours in it — BLACKPINK's "GO" and LISA's "Dream"
  // — and the vote payload identifies the nominee only by an opaque base64 id.
  // This page has both the id (in some attribute of the nominee's own card) and
  // the name, so the background script asks us to join them up.
  //
  // Deliberately shape-agnostic: find ANY element carrying the id in an
  // attribute, then walk up until an ancestor's text mentions a name. The
  // background only trusts a reply that matches a nominee its category already
  // declares, so a wrong guess here can't mis-credit anyone.
  if (AWARD === 'breaktudo') safeCtx(() => chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (!msg || msg.type !== 'bu-bt-nominee' || !msg.id) return;
    let name = null;
    try {
      const id = String(msg.id);
      const el = [...document.querySelectorAll('*')].find((n) => {
        for (const a of n.attributes) if (a.value && a.value.indexOf(id) !== -1) return true;
        return false;
      });
      const NAMES = /(BLACKPINK|JISOO|JENNIE|ROS[EÉ]|LISA|BLINKS?)/i;
      for (let n = el, up = 0; n && up < 6; n = n.parentElement, up++) {
        const t = (n.textContent || '').replace(/\s+/g, ' ').trim();
        // Stop climbing once the subtree is big enough to be the whole list of
        // nominees — a match there would say nothing about THIS one.
        if (t.length > 400) break;
        const m = t.match(NAMES);
        if (m) { name = m[1]; break; }
      }
    } catch (_) { name = null; }
    sendResponse({ name });
    return true;
  }));

  const HEART = (() => { try { return chrome.runtime.getURL('assets/heart.png'); } catch (_) { return ''; } })();
  const STICK = (() => { try { return chrome.runtime.getURL('assets/lightstick.png'); } catch (_) { return ''; } })();

  const host = document.createElement('div');
  host.id = 'bu-vote-panel-host';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'open' });

  root.innerHTML = `
    <style>
      :host{ all:initial; }
      *{ box-sizing:border-box; margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; }
      .panel{
        position:fixed; top:96px; right:22px; width:290px;
        color:#fff2f6;
        background:
          radial-gradient(120% 80% at 50% -10%, #3a0c22 0%, transparent 55%),
          linear-gradient(180deg,#15070c 0%, #0c0509 100%);
        border-radius:16px; border:1px solid #4a1526;
        box-shadow:0 18px 50px -12px #000, 0 0 0 1px #ff2e7733, inset 0 0 46px #ff2e7718;
        overflow:hidden; user-select:none;
      }
      /* Power hour / double day — gold glow + pulse while 2x votes are live */
      .panel.power{ border-color:#f5c54288; animation:powerGlow 1.8s ease-in-out infinite; }
      @keyframes powerGlow{
        0%,100%{ box-shadow:0 18px 50px -12px #000, 0 0 0 1px #f5c54288, 0 0 22px -6px #f5c54255, inset 0 0 46px #ff2e7718; }
        50%    { box-shadow:0 18px 50px -12px #000, 0 0 0 1px #f5c542ff, 0 0 46px 0 #f5c542aa, inset 0 0 46px #f5c54222; }
      }
      .powerband{ display:none; margin:0 12px 10px; padding:7px 10px; border-radius:11px; text-align:center;
        font-size:10.5px; font-weight:700; letter-spacing:.03em; color:#f7e6b0; background:#f5c5421c; border:1px solid #f5c54266; }
      .panel.power .powerband{ display:block; }
      @media (prefers-reduced-motion: reduce){ .panel.power{ animation:none; } }
      .head{ position:relative; padding:14px 16px 11px; text-align:center; border-bottom:1px solid #ff2e7722; cursor:grab; touch-action:none; }
      .head.dragging{ cursor:grabbing; }
      .titlerow{ display:flex; align-items:center; justify-content:center; gap:11px; }
      .stick{ height:40px; width:auto; filter:drop-shadow(0 2px 5px #000a) drop-shadow(0 0 7px #ff2e7755); }
      .stick.right{ transform:scaleX(-1); }
      .title{ font-weight:800; font-size:15px; letter-spacing:.16em;
        background:linear-gradient(90deg,#ff8fb4,#ff2e77 55%,#ff8fb4); -webkit-background-clip:text; background-clip:text; color:transparent; }
      .sub{ font-size:9px; letter-spacing:.24em; color:#d38aa4; text-transform:uppercase; margin-top:5px; }
      .btns{ position:absolute; top:7px; right:8px; display:flex; gap:6px; z-index:2; }
      .btns button{ all:unset; color:#ffb0cb; font-size:22px; font-weight:700; cursor:pointer; line-height:1;
        width:34px; height:34px; display:flex; align-items:center; justify-content:center; border-radius:9px;
        background:#ff2e7722; }
      .btns button:active{ background:#ff2e7744; }

      .live{ display:flex; align-items:center; justify-content:center; gap:7px; padding:9px 12px 2px; font-size:11px; color:#ff8fb4; }
      .live .dot{ width:7px; height:7px; border-radius:50%; background:#ff2e77; box-shadow:0 0 0 0 #ff2e7799; animation:pulse 1.8s infinite; }
      .live b{ color:#fff; font-variant-numeric:tabular-nums; }
      @keyframes pulse{ 0%{box-shadow:0 0 0 0 #ff2e7766} 70%{box-shadow:0 0 0 7px #ff2e7700} 100%{box-shadow:0 0 0 0 #ff2e7700} }

      .total{ position:relative; text-align:center; padding:8px 12px 6px; overflow:hidden; }
      .total .wm{ position:absolute; left:50%; top:54%; transform:translate(-50%,-50%); height:92px; opacity:.08; pointer-events:none; }
      .lbl{ position:relative; font-size:9px; letter-spacing:.24em; color:#d38aa4; text-transform:uppercase; }
      .num{ position:relative; font-variant-numeric:tabular-nums; font-weight:800; font-size:46px; line-height:1; margin-top:6px; text-shadow:0 0 24px #ff2e77aa; transition:transform .2s; }
      .num.bump{ transform:scale(1.12); }
      .unit{ position:relative; font-size:9.5px; letter-spacing:.18em; color:#ff8fb4; text-transform:uppercase; margin-top:6px; }

      .divider{ display:flex; align-items:center; gap:10px; margin:12px 16px 8px; }
      .divider::before,.divider::after{ content:""; flex:1; height:1px; background:linear-gradient(90deg,transparent,#ff2e7755,transparent); }
      .divider img{ height:18px; filter:drop-shadow(0 0 5px #ff2e7788); }

      .splits{ display:flex; gap:8px; padding:2px 14px 12px; }
      .chip{ flex:1; background:#ff2e7710; border:1px solid #ff2e7733; border-radius:11px; padding:9px 8px; text-align:center; }
      .chip .who{ font-size:10px; letter-spacing:.1em; color:#ff8fb4; text-transform:uppercase; }
      .chip .v{ font-variant-numeric:tabular-nums; font-weight:800; font-size:20px; margin-top:3px; }

      /* BreakTudo per-category breakdown. VMA has its own two-chip split above;
         BreakTudo has eight categories, so it lists rather than chips. */
      .btcats{ margin:2px 12px 10px; background:#0a0407; border:1px solid #ff2e7722; border-radius:11px; padding:8px 8px 4px; }
      .btcats .hd{ font-size:9px; letter-spacing:.16em; text-transform:uppercase; color:#8a5c6c; padding:2px 4px 6px; }
      .btcrow{ display:flex; align-items:center; gap:8px; font-size:11.5px; padding:5px 4px; border-bottom:1px dashed #ff2e7718; }
      .btcrow:last-child{ border-bottom:0; }
      .btcrow .nm{ flex:1; color:#fff2f6; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
      .btcrow .vv{ color:#ff8fb4; font-weight:800; font-variant-numeric:tabular-nums; }
      .btcats .empty{ color:#8a5c6c; font-size:11px; text-align:center; padding:8px 4px; }
      .btdiag{ margin:0 12px 10px; background:#170a0f; border:1px solid #ffb02e44; border-radius:11px; padding:8px 10px; font-size:11px; line-height:1.45; color:#ffd9a8; }
      .btdiag b{ color:#fff2f6; }
      .btdiag .why{ display:block; color:#e8c79a; margin-top:3px; }

      .log{ margin:2px 12px 12px; background:#0a0407; border:1px solid #ff2e7722; border-radius:11px; padding:8px 8px 4px; max-height:168px; overflow-y:auto; overflow-x:hidden; }
      .log::-webkit-scrollbar,.acctList::-webkit-scrollbar{ width:6px; } .log::-webkit-scrollbar-thumb,.acctList::-webkit-scrollbar-thumb{ background:#ff2e7744; border-radius:3px; }
      .loghd{ font-size:9px; letter-spacing:.16em; text-transform:uppercase; color:#8a5c6c; padding:2px 4px 6px; position:sticky; top:0; background:#0a0407; }
      .log .empty{ color:#8a5c6c; font-size:11px; text-align:center; padding:10px 4px; }
      .row{ display:flex; align-items:center; gap:7px; font-size:11.5px; padding:5px 4px; border-bottom:1px dashed #ff2e7718; }
      .row:last-child{ border-bottom:0; }
      .row img{ height:13px; flex:none; }
      .plus{ color:#ff2e77; font-weight:800; font-variant-numeric:tabular-nums; }
      .cat{ color:#fff2f6; flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
      .time{ color:#8a5c6c; font-size:10px; }

      .accts{ margin:0 12px 12px; }
      .acctToggle{ all:unset; display:flex; align-items:center; gap:6px; width:100%; cursor:pointer;
        font-size:11px; color:#d38aa4; padding:2px 2px 6px; }
      .acctToggle:hover{ color:#ff8fb4; }
      .acctToggle .caret{ margin-left:auto; color:#8a5c6c; }
      .acctList{ background:#0a0407; border:1px solid #ff2e7722; border-radius:11px; padding:6px 8px; max-height:168px; overflow-y:auto; overflow-x:hidden; }
      .acctRow{ display:flex; align-items:center; gap:8px; font-size:11px; padding:4px 2px; border-bottom:1px dashed #ff2e7714; }
      .acctRow:last-child{ border-bottom:0; }
      .aid{ flex:1; color:#fff2f6; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
      .am{ font-size:9px; letter-spacing:.06em; text-transform:uppercase; color:#12000a; background:#ff8fb4; border-radius:5px; padding:2px 5px; }
      .av{ color:#ff8fb4; font-variant-numeric:tabular-nums; min-width:26px; text-align:right; }
      .cov{ font-size:9px; font-weight:800; letter-spacing:.02em; border-radius:5px; padding:2px 5px; flex:none; }
      .cov1{ color:#ffb0cb; background:#ff2e7722; }
      .cov2{ color:#12000a; background:#ff8fb4; }
      .acctNote{ font-size:9px; color:#8a5c6c; text-align:center; padding:6px 2px 2px; }

      .sync{ display:flex; align-items:center; justify-content:space-between; gap:8px; margin:0 12px 12px; padding:8px 10px; background:#ff2e770a; border:1px solid #ff2e7722; border-radius:11px; }
      .sync .lab{ font-size:11px; color:#d38aa4; }
      .sync .lab b{ color:#ff8fb4; font-weight:700; }
      .sync .lab .sub{ display:block; font-size:9px; color:#8a5c6c; margin-top:2px; }
      .toggle{ all:unset; cursor:pointer; flex:none; width:36px; height:20px; border-radius:11px; background:#3a1622; position:relative; transition:background .15s; }
      .toggle[aria-checked="true"]{ background:#ff2e77; }
      .toggle .knob{ position:absolute; top:2px; left:2px; width:16px; height:16px; border-radius:50%; background:#fff; transition:left .15s; }
      .toggle[aria-checked="true"] .knob{ left:18px; }
      .syncedTag{ font-size:8.5px; letter-spacing:.06em; text-transform:uppercase; color:#12000a; background:#ff8fb4; border-radius:5px; padding:1px 5px; margin-left:6px; }

      .foot{ display:flex; align-items:center; justify-content:space-between; gap:8px; padding:9px 14px; border-top:1px solid #ff2e7722; background:#0a0407; }
      .status{ display:flex; align-items:center; gap:6px; font-size:10.5px; color:#d38aa4; }
      .status .d{ width:7px; height:7px; border-radius:50%; }
      .status.on .d{ background:#ff2e77; box-shadow:0 0 6px #ff2e77; }
      .status.off .d{ background:#7a4a58; }
      .link{ all:unset; color:#ff8fb4; font-size:10.5px; cursor:pointer; text-decoration:underline; }
      .brand{ font-size:9px; letter-spacing:.1em; color:#8a5c6c; text-transform:uppercase; }

      /* Collapsed "pill" — a small draggable chip that never blocks the vote UI. */
      .pill{ display:none; align-items:center; gap:8px; padding:11px 15px; cursor:grab; touch-action:none; }
      .pill img{ height:20px; filter:drop-shadow(0 0 5px #ff2e7788); }
      .pill .pk{ font-weight:800; letter-spacing:.1em; font-size:12px;
        background:linear-gradient(90deg,#ff8fb4,#ff2e77 55%,#ff8fb4); -webkit-background-clip:text; background-clip:text; color:transparent; }
      .pill .pn{ font-variant-numeric:tabular-nums; font-weight:800; font-size:16px; color:#fff; }
      .pill .pex{ margin-left:2px; color:#ffb0cb; font-size:15px; }
      .body.collapsed{ display:none; }
      .panel.min{ width:auto; }
      .panel.min .head, .panel.min .body{ display:none; }
      .panel.min .pill{ display:flex; }

      /* ── Height & resizing ─────────────────────────────────────────────────
         The panel must never be taller than the window. The resize grip lives on
         its bottom edge, so once that edge dropped below the fold — which the
         BreakTudo build does easily, with eight category rows above the log —
         the grip could not be reached at all without zooming the page out.
         So the column layout and the scrolling body are now the DEFAULT, with a
         max-height set from the panel's own top (see fitToViewport). When the
         content fits, this renders exactly as it did before. */
      .panel{ display:flex; flex-direction:column; }
      .panel .head{ flex:none; }
      .panel .body{ flex:1 1 auto; min-height:0; display:flex; flex-direction:column;
        overflow-y:auto; overflow-x:hidden; }
      /* Everything keeps its natural height and the activity log absorbs the
         slack — seeing more of the log is the reason to make this bigger. */
      .panel .body > *{ flex:0 0 auto; }
      /* .sized is only set once the grip has been dragged: then the log stretches
         into the height you dragged out, instead of keeping its own scrollbox. */
      .panel.sized .log{ flex:1 1 auto; max-height:none; min-height:54px; }
      .panel .body::-webkit-scrollbar{ width:6px; }
      .panel .body::-webkit-scrollbar-thumb{ background:#ff2e7744; border-radius:3px; }

      .grip{ position:absolute; right:0; bottom:0; width:24px; height:24px; z-index:3;
        display:none; cursor:nwse-resize; touch-action:none; }
      /* Two nested corner marks — the conventional resize affordance. It has to
         read without a hover, since on the phone build there isn't one. */
      .grip::before{ content:""; position:absolute; right:5px; bottom:5px; width:11px; height:11px;
        border-right:2px solid #ff2e77cc; border-bottom:2px solid #ff2e77cc; border-radius:0 0 4px 0; }
      .grip::after{ content:""; position:absolute; right:5px; bottom:5px; width:5px; height:5px;
        border-right:2px solid #ff2e7788; border-bottom:2px solid #ff2e7788; }
      .grip:hover::before,.grip:hover::after{ border-color:#ff8fb4; }
      .panel:not(.min) .grip{ display:block; }
    </style>

    <div class="panel" id="panel">
      <div class="pill" id="pill">
        <img src="${HEART}" alt=""><span class="pk">BU</span><span class="pn" id="pillnum">0</span><span class="pex">▸</span>
      </div>
      <div class="head" id="head">
        <div class="btns">
          <button id="min" title="Collapse">–</button>
        </div>
        <div class="titlerow">
          <img class="stick left" src="${STICK}" alt="">
          <div>
            <div class="title">BLINKS UNITED</div>
            <div class="sub">VMA Vote Counter</div>
          </div>
          <img class="stick right" src="${STICK}" alt="">
        </div>
      </div>

      <div class="body" id="body">
        <div class="live"><span class="dot"></span><b id="live">–</b> blinks voting now</div>
        <div class="powerband" id="powerband">⚡ Power hour — 2× votes now</div>

        <div class="total">
          <img class="wm" src="${HEART}" alt="">
          <div class="lbl">Counted today</div>
          <div class="num" id="total">0</div>
          <div class="unit">votes · synced to /voting</div>
        </div>

        <div class="divider"><img src="${HEART}" alt=""></div>

        <div class="splits">
          <div class="chip"><div class="who">BLACKPINK</div><div class="v" id="bp">0</div></div>
          <div class="chip"><div class="who">LISA</div><div class="v" id="lisa">0</div></div>
        </div>

        <div class="btcats" id="btcats" style="display:none"></div>
        <div class="btdiag" id="btdiag" style="display:none"></div>

        <div class="log" id="log"></div>

        <div class="accts" id="accts"></div>

        <div class="sync">
          <span class="lab"><b>⇄ Share voting accounts</b>
            <span class="sub" id="syncSub">Off — today’s voting accounts stay on this device</span></span>
          <button class="toggle" id="syncToggle" role="switch" aria-checked="false"
            title="Merge your counts and accounts-used list across every device you enable this on. Stores your voting emails to your BU account (only you can see them)."><span class="knob"></span></button>
        </div>

        <div class="foot">
          <span class="status off" id="status"><span class="d"></span><span id="statusTxt">Not linked</span></span>
          <span class="brand">blinksunited.com</span>
        </div>
      </div>

      <div class="grip" id="grip" title="Drag to resize · double-click to reset"></div>
    </div>
  `;

  (document.body || document.documentElement).appendChild(host);

  const $ = (id) => root.getElementById(id);

  // Award-specific chrome. BreakTudo has no per-member split, no power hours, no
  // per-account roster / account-sharing (you vote on-site with no account), so
  // those VMA-only sections are hidden — the total + activity log carry it.
  (function configureForAward() {
    const subEl = root.querySelector('.sub');
    if (subEl) subEl.textContent = CFG.sub;
    const unitEl = root.querySelector('.unit');
    if (unitEl) unitEl.textContent = CFG.unit;
    if (AWARD === 'breaktudo') {
      ['.splits', '.sync', '.powerband'].forEach((sel) => {
        const el = root.querySelector(sel); if (el) el.style.display = 'none';
      });
      const accts = root.getElementById('accts'); if (accts) accts.style.display = 'none';
    }
  })();
  const elPanel = $('panel'), elBody = $('body'), elHead = $('head');
  const elTotal = $('total'), elBP = $('bp'), elLisa = $('lisa'), elLog = $('log');
  const elLive = $('live'), elStatus = $('status'), elStatusTxt = $('statusTxt'), elMin = $('min');
  const elAccts = $('accts');
  const elSyncToggle = $('syncToggle'), elSyncSub = $('syncSub');
  const elPill = $('pill'), elPillNum = $('pillnum'), elGrip = $('grip');
  let acctOpen = false;
  let syncView = null; // last server-merged { bp, lisa, total, accounts } when sync is on

  const fmt = (n) => (n || 0).toLocaleString('en-US');
  const esc = (x) => String(x).replace(/[&<>"]/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const hm = (ts) => { try { return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch (_) { return ''; } };
  const ago = (ts) => {
    const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (s < 5) return 'now'; if (s < 60) return s + 's'; const m = Math.round(s / 60);
    if (m < 60) return m + 'm'; return Math.round(m / 60) + 'h';
  };

  // Mirrors BT_CATS in background.js. A content script cannot import from the
  // service worker, and the codebase already mirrors VMA_POWER between panel.js
  // and popup.js for the same reason. An unrecognised slug is prettified rather
  // than shown raw or dropped, so the two drifting apart degrades to a slightly
  // clumsy label instead of a missing or cryptic row.
  const BT_CAT_LABELS = {
    'grupo-feminino-internacional':     'Int. Female Group',
    'artista-feminina-internacional':   'Int. Female Artist',
    'artista-asiatico':                 'Asian Artist',
    'colaboracao-internacional-do-ano': 'Int. Collaboration',
    'hit-internacional-do-ano':         'Int. Hit of the Year',
    'videoclipe-internacional-do-ano':  'Int. Music Video',
    'videoclipe-internacional':         'Int. Music Video',
    // The live site uses the clipe- spelling — the by-category list was falling
    // back to title-casing the raw slug ("Clipe Internacional Do Ano").
    'clipe-internacional-do-ano':       'Int. Music Video',
    'clipe-internacional':              'Int. Music Video',
    'fandom-internacional-do-ano':      'Int. Fandom',
    'serie-internacional':              'Int. Series',
    'serie-internacional-do-ano':       'Int. Series',
    _other:                             'Category not identified',
  };
  const btCatLabel = (slug) => BT_CAT_LABELS[slug]
    || String(slug).replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

  function renderBtCats(map) {
    const el = $('btcats');
    if (!el) return;
    const entries = Object.entries(map || {})
      .filter(([, v]) => (Number(v) || 0) > 0)
      .sort((a, b) => b[1] - a[1]);
    el.style.display = 'block';
    if (!entries.length) {
      el.innerHTML = '<div class="hd">By category · today</div>'
        + '<div class="empty">No votes counted yet today.</div>';
      return;
    }
    el.innerHTML = '<div class="hd">By category · today</div>'
      + entries.map(([k, v]) =>
          '<div class="btcrow"><span class="nm">' + esc(btCatLabel(k)) + '</span>'
          + '<span class="vv">' + fmt(v) + '</span></div>').join('');
  }

  // Why the last thing we saw was NOT counted. A vote that doesn't register used
  // to be completely silent — the counter just sat there and there was nothing to
  // report but "it isn't working". Only shown when something actually went wrong.
  function renderBtDiag(list) {
    const el = $('btdiag');
    if (!el) return;
    // Newest entry only. Searching past it for the most recent *failure* meant a
    // vote that counted fine afterwards still left the warning on screen.
    const last = (Array.isArray(list) && list[0] && list[0].kind && list[0].kind !== 'counted') ? list[0] : null;
    // Stale complaints are noise — anything older than 10 minutes has been
    // superseded by whatever happened since.
    if (!last || Date.now() - (last.ts || 0) > 600000) { el.style.display = 'none'; return; }
    let msg;
    if (last.kind === 'held' && last.reason === 'not-linked') {
      msg = '<b>Votes are being seen but not logged.</b><span class="why">Open the extension and tap “Link my account” — ' + fmt(last.n) + ' vote' + (last.n === 1 ? '' : 's') + ' are being held until you do.</span>';
    } else if (last.kind === 'held') {
      msg = '<b>Couldn’t reach blinksunited.com.</b><span class="why">' + fmt(last.n) + ' vote' + (last.n === 1 ? '' : 's') + ' are held and will be sent on the next one that goes through.</span>';
    } else if (last.kind === 'not-ours') {
      msg = '<b>Not counted — category not recognised.</b><span class="why">' + esc(last.slug || 'unknown page') + ' isn’t on the BLACKPINK list. If BLACKPINK or a member IS nominated here, send us this page name.</span>';
    } else if (last.kind === 'rejected') {
      msg = '<b>BreakTudo rejected that vote (' + esc(String(last.status || '?')) + ').</b><span class="why">Nothing was counted — try again.</span>';
    } else if (last.kind === 'unreadable') {
      msg = '<b>A vote went out in a shape we couldn’t read.</b><span class="why">' + esc(last.path || '') + ' — send us this and we’ll fix the counter.</span>';
    } else { el.style.display = 'none'; return; }
    el.style.display = 'block';
    el.innerHTML = '⚠️ ' + msg;
  }

  let lastTotal = 0;
  // 2026 VMA power schedule (US Eastern), mirrors blinksunited.com/voting:
  //   Power Hour 1:00–1:59 PM ET daily Aug 20 → Sep 24; Double Days Aug 18/19, Sep 25.
  const VMA_POWER = { hourStart: 13, hourEnd: 14, hourFrom: '2026-08-20', hourTo: '2026-09-24',
    doubleDays: ['2026-08-18', '2026-08-19', '2026-09-25'] };
  function vmaEtParts(d) {
    const p = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hour12: false })
      .formatToParts(d).reduce((o, x) => (o[x.type] = x.value, o), {});
    return { date: `${p.year}-${p.month}-${p.day}`, hour: parseInt(p.hour, 10) % 24 };
  }
  function vmaPowerLabel() {
    const { date, hour } = vmaEtParts(new Date());
    if (VMA_POWER.doubleDays.indexOf(date) !== -1) return 'Double day';
    if (date >= VMA_POWER.hourFrom && date <= VMA_POWER.hourTo && hour >= VMA_POWER.hourStart && hour < VMA_POWER.hourEnd) return 'Power hour';
    return '';
  }

  function render(s) {
    // Power hour / double day → gold glow + banner (VMA-only, schedule-driven).
    if (AWARD === 'vma') {
      const plabel = vmaPowerLabel();
      $('panel').classList.toggle('power', !!plabel);
      if (plabel) $('powerband').textContent = '⚡ ' + plabel + ' — 2× votes now';
    }

    // When cross-device sync is on and we have a server view, show the merged
    // numbers/accounts; otherwise show this device's local ones.
    // COUNTS: whenever linked, show this account's SERVER total for today — the exact
    // same data as the /voting leaderboard, already merged across every browser /
    // profile / device. Local counts are only a fallback before the first server pull
    // or when not linked. (Device-sync no longer affects the counts — they always merge.)
    const view = (s.buToken && syncView) ? syncView : null;
    const acctSynced = !!s.buSyncOn && !!view;   // only the accounts-used list is sync-gated

    const total = view ? (view.total || 0) : (s[CFG.countKey] || 0);
    if (total !== lastTotal) { elTotal.classList.add('bump'); setTimeout(() => elTotal.classList.remove('bump'), 200); lastTotal = total; }
    elTotal.textContent = fmt(total);
    elPillNum.textContent = fmt(total);
    if (AWARD === 'vma') {
      elBP.textContent = fmt(view ? view.bp : s.bpCount);
      elLisa.textContent = fmt(view ? view.lisa : s.lisaCount);
    }

    // Sync toggle + caption (VMA-only — the account-sharing UI is hidden on BreakTudo).
    // Your vote counts merge across devices automatically once linked; this toggle
    // only shares the *voting accounts* (emails) you've used today across your devices.
    if (AWARD === 'vma') {
      elSyncToggle.setAttribute('aria-checked', s.buSyncOn ? 'true' : 'false');
      elSyncSub.textContent = s.buSyncOn
        ? 'On — sharing today’s voting accounts across your devices'
        : 'Off — today’s voting accounts stay on this device';
    }

    if (AWARD === 'breaktudo') { renderBtCats(s.btCats); renderBtDiag(s.btDiag); }

    const log = Array.isArray(s[CFG.logKey]) ? s[CFG.logKey] : [];
    if (!log.length) {
      elLog.innerHTML = '<div class="empty">No votes counted yet — vote on this page and they’ll appear here.</div>';
    } else {
      // Full chronology for today (newest first), with the time each was cast.
      elLog.innerHTML = '<div class="loghd">Today’s votes · ' + log.length + '</div>'
        + log.map((e) =>
          '<div class="row"><img src="' + HEART + '" alt=""><span class="plus">+' + e.n + '</span>'
          + '<span class="cat">' + e.cat + ' · ' + e.who + '</span>'
          + '<span class="time">' + hm(e.ts) + '</span></div>'
        ).join('');
    }

    if (s.buToken) {
      elStatus.className = 'status on';
      elStatusTxt.textContent = s.buProfile ? ('Linked · ' + s.buProfile) : 'Linked';
    } else {
      elStatus.className = 'status off';
      elStatusTxt.innerHTML = '<button class="link" id="linkBtn">Link your account</button>';
      const lb = root.getElementById('linkBtn');
      if (lb) lb.onclick = () => window.open('https://blinksunited.com/vote-link.html', '_blank');
    }

    // Accounts you've voted with today (VMA-only; the section is hidden on BreakTudo).
    // Local to this browser unless sync is on, in which case it's the merged list.
    if (AWARD !== 'vma') return;
    const accts = acctSynced ? (view.accounts || []) : (Array.isArray(s.buAccounts) ? s.buAccounts : []);
    let ah = '<button class="acctToggle" id="acctToggle">🔑 Accounts used today · ' + accts.length
      + (acctSynced ? '<span class="syncedTag">synced</span>' : '')
      + '<span class="caret">' + (acctOpen ? '▾' : '▸') + '</span></button>';
    if (acctOpen) {
      if (accts.length) {
        const sorted = accts.slice().sort((a, b) => (b.lastTs || 0) - (a.lastTs || 0) || (b.votes || 0) - (a.votes || 0));
        ah += '<div class="acctList">' + sorted.map((a) => {
          const cov = Math.min(2, Array.isArray(a.cats) ? a.cats.length : 0);
          return '<div class="acctRow"><span class="aid" title="' + esc(a.id) + '">' + esc(a.id) + '</span>'
          + '<span class="am">' + esc(a.method || 'email') + '</span>'
          + (cov ? '<span class="cov cov' + cov + '" title="voted ' + cov + ' of 2 categories">' + cov + '/2</span>' : '')
          + '<span class="av">' + fmt(a.votes) + '</span></div>';
        }).join('')
          + '<div class="acctNote">' + (acctSynced ? 'Synced to your BU account — only you can see this' : 'Stored on this device only') + '</div></div>';
      } else {
        ah += '<div class="acctList"><div class="acctNote">No accounts yet — vote and the emails/logins you use will appear here.</div></div>';
      }
    }
    elAccts.innerHTML = ah;
    const at = root.getElementById('acctToggle');
    if (at) at.onclick = () => { acctOpen = !acctOpen; refresh(); };
  }

  const KEYS = ['buCount', 'bpCount', 'lisaCount', 'buLog', 'buAccounts', 'buToken', 'buProfile', 'buSyncOn', 'buPanelPos', 'buPanelMin', 'buPanelSize', 'btCount', 'btLog', 'btDay', 'btCats', 'btDiag'];
  // fitToViewport AFTER render: the panel's natural height depends on how many
  // category rows and log entries were just drawn.
  function refresh() { safeCtx(() => chrome.storage.local.get(KEYS, (s) => { applyLayout(s); render(s); fitToViewport(); })); }

  // React to background updates immediately.
  safeCtx(() => chrome.storage.onChanged.addListener((changes, area) => {
    if (!validCtx()) return;
    if (area !== 'local') return;
    if (Object.keys(changes).some((k) => KEYS.includes(k))) refresh();
    // A vote just landed for this award — pull the merged view too.
    if (changes[CFG.countKey]) pollSync();
  }));
  // Keep the relative timestamps fresh.
  setInterval(refresh, 15000);

  // ── cross-device sync (opt-in) ──
  function pollSync() {
    safeCtx(() => {
      chrome.storage.local.get(['buToken'], (s) => {
        // Pull the account's server total whenever linked — counts always merge across
        // devices now, independent of the device-sync toggle.
        if (!s.buToken) { if (syncView) { syncView = null; refresh(); } return; }
        try {
          chrome.runtime.sendMessage({ type: 'bu-sync-pull', award: AWARD }, (resp) => {
            if (chrome.runtime.lastError) return;
            if (resp && resp.data) { syncView = resp.data; refresh(); }
          });
        } catch (_) {}
      });
    });
  }
  elSyncToggle.onclick = () => {
    safeCtx(() => {
      chrome.storage.local.get(['buToken', 'buSyncOn'], (s) => {
        if (!s.buToken) { window.open('https://blinksunited.com/vote-link.html', '_blank'); return; }
        const next = !s.buSyncOn;
        // Keep the merged server counts regardless; just re-pull so the accounts list updates.
        safeCtx(() => chrome.storage.local.set({ buSyncOn: next }, () => { pollSync(); refresh(); }));
      });
    });
  };
  pollSync();
  setInterval(pollSync, 20000);

  // ── live "voting now" poll ──
  function pollLive() {
    try {
      chrome.runtime.sendMessage({ type: 'bu-live', award: AWARD }, (resp) => {
        if (chrome.runtime.lastError) return;
        if (resp && typeof resp.liveVoters === 'number') elLive.textContent = fmt(resp.liveVoters);
      });
    } catch (_) {}
  }
  pollLive();
  setInterval(pollLive, 20000);

  // ── collapse / expand ──
  // On phones the panel starts collapsed as a small pill so it never covers the vote
  // button; on desktop it starts open. Once the user toggles, their choice sticks.
  function isMin(s) {
    return s.buPanelMin === undefined ? (window.innerWidth < 560) : !!s.buPanelMin;
  }
  function applyLayout(s) {
    const min = isMin(s);
    elBody.classList.toggle('collapsed', min);
    elPanel.classList.toggle('min', min);
    const pos = s.buPanelPos;
    if (pos && typeof pos.left === 'number') {
      // A position saved on a bigger window can put the panel (and its grip)
      // off the bottom of a smaller one, so clamp it on the way back in.
      const top = Math.max(4, Math.min(Math.max(4, window.innerHeight - MIN_H - 8), pos.top));
      const left = Math.max(4, Math.min(Math.max(4, window.innerWidth - 48), pos.left));
      elPanel.style.left = left + 'px'; elPanel.style.top = top + 'px'; elPanel.style.right = 'auto';
    }
    // The pill is never sized — collapsing drops back to its natural chip size,
    // and expanding restores whatever the panel was resized to.
    const size = s.buPanelSize;
    if (!min && size && typeof size.w === 'number') applySize(size.w, size.h);
    else clearSizeStyles();
  }
  let justDragged = false;
  const setMin = (v) => safeCtx(() => chrome.storage.local.set({ buPanelMin: v }));
  elMin.onclick = (e) => { e.stopPropagation(); if (!justDragged) setMin(true); };
  elPill.addEventListener('click', () => { if (!justDragged) setMin(false); });

  // ── resize (drag the corner grip; double-click it to go back to default) ──
  // Pointer events, like the drag handler below, so it works with touch on Kiwi.
  const MIN_W = 232, MIN_H = 200;  // below this the splits/log layout breaks up
  const maxW = () => Math.max(MIN_W, window.innerWidth - 8);
  // Measured from the panel's own top, not from the top of the window: anchored
  // at top:96px, a height of innerHeight-8 put the bottom edge 96px below the
  // fold and took the resize grip with it.
  const panelTop = () => elPanel.getBoundingClientRect().top;
  const maxH = () => Math.max(MIN_H, window.innerHeight - panelTop() - 8);

  // Keep the whole panel on screen, grip included. Called whenever the content,
  // the position or the window changes.
  function fitToViewport() {
    if (elPanel.classList.contains('min')) { elPanel.style.maxHeight = ''; return; }
    elPanel.style.maxHeight = maxH() + 'px';
  }

  function applySize(w, h) {
    const cw = Math.round(Math.max(MIN_W, Math.min(maxW(), w)));
    const ch = Math.round(Math.max(MIN_H, Math.min(maxH(), h)));
    elPanel.style.width = cw + 'px';
    elPanel.style.height = ch + 'px';
    elPanel.classList.add('sized');
    return { w: cw, h: ch };
  }
  function clearSizeStyles() {
    elPanel.style.width = ''; elPanel.style.height = '';
    elPanel.classList.remove('sized');
  }

  let rs = null;
  elGrip.addEventListener('pointerdown', (e) => {
    const r = elPanel.getBoundingClientRect();
    // The panel is anchored by `right` until it has been moved. Resizing from a
    // right-anchored edge grows it leftwards and the grip stays put under your
    // finger, so pin it to left/top first and the corner follows the pointer.
    if (!elPanel.style.left) {
      elPanel.style.left = r.left + 'px'; elPanel.style.top = r.top + 'px'; elPanel.style.right = 'auto';
    }
    rs = { sx: e.clientX, sy: e.clientY, w: r.width, h: r.height };
    e.preventDefault(); e.stopPropagation();
    if (elGrip.setPointerCapture) { try { elGrip.setPointerCapture(e.pointerId); } catch (_) {} }
  });
  window.addEventListener('pointermove', (e) => {
    if (!rs) return;
    applySize(rs.w + (e.clientX - rs.sx), rs.h + (e.clientY - rs.sy));
    e.preventDefault();
  }, { passive: false });
  function endResize() {
    if (!rs) return;
    rs = null;
    const r = elPanel.getBoundingClientRect();
    safeCtx(() => chrome.storage.local.set({
      buPanelSize: { w: Math.round(r.width), h: Math.round(r.height) },
      buPanelPos: { left: Math.round(r.left), top: Math.round(r.top) },
    }));
  }
  window.addEventListener('pointerup', endResize);
  window.addEventListener('pointercancel', endResize);
  elGrip.addEventListener('dblclick', (e) => {
    e.stopPropagation();
    clearSizeStyles();
    safeCtx(() => chrome.storage.local.remove('buPanelSize'));
  });
  // Re-clamp after a rotate or window resize, so a size saved on a big screen
  // can't leave the panel taller than the phone it's opened on next.
  window.addEventListener('resize', () => {
    fitToViewport();
    if (!elPanel.classList.contains('sized')) return;
    const r = elPanel.getBoundingClientRect();
    safeCtx(() => chrome.storage.local.set({ buPanelSize: applySize(r.width, r.height) }));
  });

  // ── drag (pointer events → works with touch on Kiwi/mobile) ──
  let drag = null;
  function onDown(e) {
    if (e.target.closest('.btns')) return; // let the collapse button work
    const r = elPanel.getBoundingClientRect();
    drag = { dx: e.clientX - r.left, dy: e.clientY - r.top, sx: e.clientX, sy: e.clientY, moved: false };
    elHead.classList.add('dragging');
  }
  function onMove(e) {
    if (!drag) return;
    if (Math.abs(e.clientX - drag.sx) > 4 || Math.abs(e.clientY - drag.sy) > 4) drag.moved = true;
    const left = Math.max(4, Math.min(window.innerWidth - 48, e.clientX - drag.dx));
    // Leave room for at least a minimum-height panel below the drop point, so
    // the bottom edge — and the grip on it — stays reachable.
    const top = Math.max(4, Math.min(Math.max(4, window.innerHeight - MIN_H - 8), e.clientY - drag.dy));
    elPanel.style.left = left + 'px'; elPanel.style.top = top + 'px'; elPanel.style.right = 'auto';
    fitToViewport();
    if (drag.moved) e.preventDefault();
  }
  function onUp() {
    if (!drag) return;
    const moved = drag.moved; drag = null; elHead.classList.remove('dragging');
    const r = elPanel.getBoundingClientRect();
    safeCtx(() => chrome.storage.local.set({ buPanelPos: { left: r.left, top: r.top } }));
    if (moved) { justDragged = true; setTimeout(() => { justDragged = false; }, 250); }
  }
  elHead.addEventListener('pointerdown', onDown);
  elPill.addEventListener('pointerdown', onDown);
  window.addEventListener('pointermove', onMove, { passive: false });
  window.addEventListener('pointerup', onUp);
  window.addEventListener('pointercancel', onUp);

  refresh();
})();
